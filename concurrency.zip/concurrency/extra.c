#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>

#define MAX_THREADS 4
#define MAX_FILES 100

typedef struct {
    char name[128];
    int id;
    char timestamp[20];
} File;

typedef struct {
    File *data;
    int start;
    int end;
    char sortBy[10];
} Task;

File files[MAX_FILES];
int file_count;

pthread_mutex_t queue_lock = PTHREAD_MUTEX_INITIALIZER;
sem_t available_threads;

Task *task_queue[MAX_FILES];
int task_count = 0;
int task_front = 0;

int compareByID(const void *a, const void *b) {
    return ((File *)a)->id - ((File *)b)->id;
}

int compareByName(const void *a, const void *b) {
    return strcmp(((File *)a)->name, ((File *)b)->name);
}

int compareByTimestamp(const void *a, const void *b) {
    return strcmp(((File *)a)->timestamp, ((File *)b)->timestamp);
}

// Enqueue task
void enqueue_task(Task *task) {
    pthread_mutex_lock(&queue_lock);
    task_queue[task_count++] = task;
    pthread_mutex_unlock(&queue_lock);
}

// Dequeue task
Task* dequeue_task() {
    pthread_mutex_lock(&queue_lock);
    Task *task = NULL;
    if (task_front < task_count) {
        task = task_queue[task_front++];
    }
    pthread_mutex_unlock(&queue_lock);
    return task;
}

// Worker function for sorting tasks
void* worker_thread(void *arg) {
    while (1) {
        sem_wait(&available_threads);

        Task *task = dequeue_task();
        if (!task) {
            sem_post(&available_threads);
            return NULL;
        }

        if (strcmp(task->sortBy, "ID") == 0) {
            qsort(task->data + task->start, task->end - task->start, sizeof(File), compareByID);
        } else if (strcmp(task->sortBy, "Name") == 0) {
            qsort(task->data + task->start, task->end - task->start, sizeof(File), compareByName);
        } else if (strcmp(task->sortBy, "Timestamp") == 0) {
            qsort(task->data + task->start, task->end - task->start, sizeof(File), compareByTimestamp);
        }

        free(task);
        sem_post(&available_threads);
    }
}

// Merge function to combine sorted chunks
void merge(File *data, int start, int mid, int end, int (*compare)(const void *, const void *)) {
    int left_size = mid - start + 1;
    int right_size = end - mid;

    File *left = malloc(left_size * sizeof(File));
    File *right = malloc(right_size * sizeof(File));

    for (int i = 0; i < left_size; i++) left[i] = data[start + i];
    for (int i = 0; i < right_size; i++) right[i] = data[mid + 1 + i];

    int i = 0, j = 0, k = start;
    while (i < left_size && j < right_size) {
        if (compare(&left[i], &right[j]) <= 0) {
            data[k++] = left[i++];
        } else {
            data[k++] = right[j++];
        }
    }
    while (i < left_size) data[k++] = left[i++];
    while (j < right_size) data[k++] = right[j++];

    free(left);
    free(right);
}

// Coordinator function
void coordinator(char *sortBy) {
    int chunk_size = file_count / MAX_THREADS;
    if (chunk_size < 1) chunk_size = 1;

    for (int i = 0; i < file_count; i += chunk_size) {
        Task *task = malloc(sizeof(Task));
        task->data = files;
        task->start = i;
        task->end = (i + chunk_size < file_count) ? i + chunk_size : file_count;
        strcpy(task->sortBy, sortBy);
        enqueue_task(task);
    }

    pthread_t threads[MAX_THREADS];
    for (int i = 0; i < MAX_THREADS; i++) {
        pthread_create(&threads[i], NULL, worker_thread, NULL);
    }

    for (int i = 0; i < MAX_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    int (*compare_func)(const void *, const void *);
    if (strcmp(sortBy, "ID") == 0) compare_func = compareByID;
    else if (strcmp(sortBy, "Name") == 0) compare_func = compareByName;
    else compare_func = compareByTimestamp;

    for (int size = chunk_size; size < file_count; size *= 2) {
        for (int start = 0; start < file_count; start += 2 * size) {
            int mid = start + size - 1;
            int end = (start + 2 * size - 1 < file_count) ? start + 2 * size - 1 : file_count - 1;
            if (mid < end) merge(files, start, mid, end, compare_func);
        }
    }
}

// Main function
int main() {
    sem_init(&available_threads, 0, MAX_THREADS);

    scanf("%d", &file_count);
    for (int i = 0; i < file_count; i++) {
        scanf("%s %d %s", files[i].name, &files[i].id, files[i].timestamp);
    }

    char sortBy[10];
    scanf("%s", sortBy);

    printf("Sorting by: %s\n", sortBy);
    coordinator(sortBy);

    for (int i = 0; i < file_count; i++) {
        printf("%s %d %s\n", files[i].name, files[i].id, files[i].timestamp);
    }

    sem_destroy(&available_threads);
    pthread_mutex_destroy(&queue_lock);

    return 0;
}
