#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>

#define MAX_REQUESTS 2000

#define YELLOW "\033[33m"
#define PINK "\033[95m"
#define WHITE "\033[37m"
#define GREEN "\033[32m"
#define RED "\033[31m"
#define RESET "\033[0m"

typedef enum {
    READ,
    WRITE,
    DELETE,
    INVALID
} Operation;

typedef struct {
    int user_id;
    int file_id;
    Operation op;
    int arrival_time;
    int start_time;
    int completion_time;
    int processed;
    int completed;
    int canceled;
    pthread_t thread;
    int request_index;  // Added to maintain order
} Request;

typedef struct {
    int readers;
    int writers;
    int deleted;
    int delete_in_progress;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
} FileStatus;

int read_time, write_time, delete_time;
int num_files, concurrency_limit, patience_time;
volatile int current_time = 0;
int num_requests = 0;
Request requests[MAX_REQUESTS];
FileStatus* files;
pthread_mutex_t time_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t print_mutex = PTHREAD_MUTEX_INITIALIZER;

void print_message(const char* color, const char* message) {
    pthread_mutex_lock(&print_mutex);
    printf("%s%s%s\n", color, message, RESET);
    fflush(stdout);
    pthread_mutex_unlock(&print_mutex);
}

const char* get_operation_string(Operation op) {
    switch (op) {
        case READ: return "READ";
        case WRITE: return "WRITE";
        case DELETE: return "DELETE";
        case INVALID: return "INVALID";
        default: return "UNKNOWN";
    }
}

int get_operation_time(Operation op) {
    switch (op) {
        case READ: return read_time;
        case WRITE: return write_time;
        case DELETE: return delete_time;
        default: return 0;
    }
}

// Modified to consider request ordering
int has_concurrent_priority_requests(Request* req) {
    if (req->op != DELETE) return 0;
    
    for (int i = 0; i < num_requests; i++) {
        Request* other = &requests[i];
        if (other == req || other->processed || other->canceled) continue;
        
        if (other->arrival_time == req->arrival_time && 
            other->file_id == req->file_id && 
            (other->op == READ || other->op == WRITE)) {
            if (other->request_index < req->request_index) {
                return 1;
            }
        }
    }
    return 0;
}

int is_file_valid(Request* req, FileStatus* file) {
    if (file->deleted) {
        char message[200];
        sprintf(message, "LAZY has declined the request of User %d at %d seconds because an invalid/deleted file was requested.",
                req->user_id, current_time);
        print_message(WHITE, message);
        req->canceled = 1;
        return 0;
    }
    
    if (file->delete_in_progress && (req->op == READ || req->op == WRITE || req->op == DELETE)) {
        char message[200];
        sprintf(message, "LAZY has declined the request of User %d at %d seconds because the file is being deleted.",
                req->user_id, current_time);
        print_message(WHITE, message);
        req->canceled = 1;
        return 0;
    }
    
    return 1;
}

int can_process_request(Request* req, FileStatus* file) {
    if (!is_file_valid(req, file)) return 0;
    
    if (has_concurrent_priority_requests(req)) return 0;
    
    int total_users = file->readers + file->writers;
    if (total_users >= concurrency_limit) return 0;
    
    switch (req->op) {
        case READ:
            return !file->delete_in_progress;
        case WRITE:
            return file->writers == 0 && !file->delete_in_progress;
        case DELETE:
            return total_users == 0;
        default:
            return 0;
    }
}

void* process_request(void* arg) {
    Request* req = (Request*)arg;
    if (req->op == INVALID) {
        char message[200];
        sprintf(message, "LAZY has declined the request of User %d at %d seconds because an invalid operation was requested.",
                req->user_id, req->arrival_time + 1);
        print_message(WHITE, message);
        req->canceled = 1;
        return NULL;
    }
    FileStatus* file = &files[req->file_id - 1];
    char message[200];
    int cancel_time = req->arrival_time + patience_time;
    
    // Wait for arrival time
    pthread_mutex_lock(&time_mutex);
    while (current_time < req->arrival_time) {
        pthread_mutex_unlock(&time_mutex);
        usleep(50000);
        pthread_mutex_lock(&time_mutex);
    }
    pthread_mutex_unlock(&time_mutex);
    
    sprintf(message, "User %d has made request for performing %s on file %d at %d seconds",
            req->user_id, get_operation_string(req->op), req->file_id, req->arrival_time);
    print_message(YELLOW, message);
    
    // Initial file validity check
    pthread_mutex_lock(&file->mutex);
    if (!is_file_valid(req, file)) {
        pthread_mutex_unlock(&file->mutex);
        return NULL;
    }
    pthread_mutex_unlock(&file->mutex);
    
    int process_start_time = req->arrival_time + 1;
    
    while (!req->processed && !req->canceled) {
        pthread_mutex_lock(&time_mutex);
        int current = current_time;
        pthread_mutex_unlock(&time_mutex);
        
        if (current < process_start_time) {
            usleep(50000);
            continue;
        }
        
        if (current >= cancel_time) {
            req->canceled = 1;
            sprintf(message, "User %d canceled the request due to no response at %d seconds",
                    req->user_id, current);
            print_message(RED, message);
            return NULL;
        }
        
        pthread_mutex_lock(&file->mutex);
        if (can_process_request(req, file)) {
            req->processed = 1;
            req->start_time = current;
            req->completion_time = req->start_time + get_operation_time(req->op);
            
            if (req->op == DELETE) {
                file->delete_in_progress = 1;
            }
            
            switch (req->op) {
                case READ:
                    file->readers++;
                    break;
                case WRITE:
                    file->writers++;
                    break;
                case DELETE:
                    break;
            }
            
            sprintf(message, "LAZY has taken up the request of User %d at %d seconds",
                    req->user_id, req->start_time);
            pthread_mutex_unlock(&file->mutex);
            print_message(PINK, message);
            
            while (1) {
                pthread_mutex_lock(&time_mutex);
                current = current_time;
                pthread_mutex_unlock(&time_mutex);
                
                if (current >= req->completion_time) {
                    pthread_mutex_lock(&file->mutex);
                    
                    switch (req->op) {
                        case READ:
                            file->readers--;
                            break;
                        case WRITE:
                            file->writers--;
                            break;
                        case DELETE:
                            file->deleted = 1;
                            file->delete_in_progress = 0;
                            break;
                    }
                    req->completed = 1;
                    
                    sprintf(message, "The request for User %d was completed at %d seconds",
                            req->user_id, req->completion_time);
                    pthread_cond_broadcast(&file->cond);
                    pthread_mutex_unlock(&file->mutex);
                    print_message(GREEN, message);
                    return NULL;
                }
                usleep(50000);
            }
        }
        pthread_mutex_unlock(&file->mutex);
        usleep(50000);
    }
    
    return NULL;
}

int main() {
    scanf("%d %d %d", &read_time, &write_time, &delete_time);
    scanf("%d %d %d", &num_files, &concurrency_limit, &patience_time);
    
    files = (FileStatus*)malloc(num_files * sizeof(FileStatus));
    if (files == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }
    
    for (int i = 0; i < num_files; i++) {
        files[i].readers = 0;
        files[i].writers = 0;
        files[i].deleted = 0;
        files[i].delete_in_progress = 0;
        pthread_mutex_init(&files[i].mutex, NULL);
        pthread_cond_init(&files[i].cond, NULL);
    }
    
    char op_str[10];
    while (1) {
        scanf("%s", op_str);
        if (strcmp(op_str, "STOP") == 0) break;
        
        requests[num_requests].user_id = atoi(op_str);
        scanf("%d %s %d", &requests[num_requests].file_id,
              op_str, &requests[num_requests].arrival_time);
        
        if (strcmp(op_str, "READ") == 0) requests[num_requests].op = READ;
        else if (strcmp(op_str, "WRITE") == 0) requests[num_requests].op = WRITE;
        else if (strcmp(op_str, "DELETE") == 0) requests[num_requests].op = DELETE;
        else requests[num_requests].op= INVALID;
        requests[num_requests].processed = 0;
        requests[num_requests].completed = 0;
        requests[num_requests].canceled = 0;
        requests[num_requests].request_index = num_requests;  // Store request order
        
        num_requests++;
    }
    
    print_message(WHITE, "LAZY has woken up!");
    
    for (int i = 0; i < num_requests; i++) {
        pthread_create(&requests[i].thread, NULL, process_request, &requests[i]);
    }
    
    while (1) {
        usleep(1000000);
        pthread_mutex_lock(&time_mutex);
        current_time++;
        pthread_mutex_unlock(&time_mutex);
        
        int all_done = 1;
        for (int i = 0; i < num_requests; i++) {
            if (!requests[i].completed && !requests[i].canceled) {
                all_done = 0;
                break;
            }
        }
        
        if (all_done) break;
    }
    
    for (int i = 0; i < num_requests; i++) {
        pthread_join(requests[i].thread, NULL);
    }
    
    print_message(WHITE, "\nLAZY has no more pending requests and is going back to sleep!");
    
    for (int i = 0; i < num_files; i++) {
        pthread_mutex_destroy(&files[i].mutex);
        pthread_cond_destroy(&files[i].cond);
    }
    pthread_mutex_destroy(&time_mutex);
    pthread_mutex_destroy(&print_mutex);
    
    free(files);
    
    return 0;
}