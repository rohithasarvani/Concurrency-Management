#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#define MAX_FILES 1000
#define MAX_NAME_LENGTH 128
#define THRESHOLD 42
#define MAX_THREADS 4
#define MAX_CHAR 256  // ASCII character range

typedef struct {
    char name[MAX_NAME_LENGTH];
    int id;
    char timestamp[20];
} File;

File files[MAX_FILES];
int file_count;
char sortBy[10];
File temp_files[MAX_FILES];  // Temporary array for sorting
int num_files;

// Function to parse timestamp to integer (for sorting by timestamp)
int parseTimestamp(const char *timestamp) {
    int year, month, day, hour, minute, second;
    sscanf(timestamp, "%d-%d-%dT%d:%d:%d", &year, &month, &day, &hour, &minute, &second);
    return year * 10000000000 + month * 100000000 + day * 1000000 + hour * 10000 + minute * 100 + second;
}

// Comparison functions
int compareByID(const void *a, const void *b) {
    return ((File *)a)->id - ((File *)b)->id;
}

int compareByName(const void *a, const void *b) {
    return strcmp(((File *)a)->name, ((File *)b)->name);
}

int compareByTimestamp(const void *a, const void *b) {
    int tsA = parseTimestamp(((File *)a)->timestamp);
    int tsB = parseTimestamp(((File *)b)->timestamp);
    return tsA - tsB;
}
// Function to perform counting sort on `pos`th character in the `name` field of each `File`
void countSortFiles(File files[], int n, int pos) {
    File output[n];      // Output array to store sorted files
    int count[MAX_CHAR] = {0};  // Count array to store frequency of each character

    // Store count of occurrences of each character at position `pos` in `name`
    for (int i = 0; i < n; i++) {
        int index = (pos < strlen(files[i].name)) ? (int)files[i].name[pos] : 0;  // Use 0 for shorter names
        count[index]++;
    }

    // Modify count array so that it contains the actual position of this character in output array
    for (int i = 1; i < MAX_CHAR; i++) {
        count[i] += count[i - 1];
    }

    // Build the output array
    for (int i = n - 1; i >= 0; i--) {
        int index = (pos < strlen(files[i].name)) ? (int)files[i].name[pos] : 0;
        output[count[index] - 1] = files[i];
        count[index]--;
    }

    // Copy the sorted files back to the original array
    for (int i = 0; i < n; i++) {
        files[i] = output[i];
    }
}

// Function to sort the array of `File` structs by `name` field using radix sort
void radixSortFilesByName(File files[], int n, int maxLen) {
    // Perform counting sort for each position in `name`, from least to most significant
    for (int pos = maxLen - 1; pos >= 0; pos--) {
        countSortFiles(files, n, pos);
    }
}
void count_sort_by_part(int part_index, int max_value, int (*get_part)(const File*)) {
    int *count = (int*)calloc(max_value + 1, sizeof(int));
    for (int i = 0; i < num_files; i++) {
        int part = get_part(&files[i]);
        count[part]++;
    }
    for (int i = 1; i <= max_value; i++) count[i] += count[i - 1];
    for (int i = num_files - 1; i >= 0; i--) {
        int part = get_part(&files[i]);
        temp_files[count[part] - 1] = files[i];
        count[part]--;
    }
    for (int i = 0; i < num_files; i++) files[i] = temp_files[i];
    free(count);
}

int get_second(const File *file) { return atoi(&file->timestamp[17]); }
int get_minute(const File *file) { return atoi(&file->timestamp[14]); }
int get_hour(const File *file) { return atoi(&file->timestamp[11]); }
int get_day(const File *file) { return atoi(&file->timestamp[8]); }
int get_month(const File *file) { return atoi(&file->timestamp[5]); }
int get_year(const File *file) { return atoi(&file->timestamp[0]); }

void count_sort_timestamps() {
    count_sort_by_part(5, 59, get_second);   // Sort by seconds (0-59)
    count_sort_by_part(4, 59, get_minute);   // Sort by minutes (0-59)
    count_sort_by_part(3, 23, get_hour);     // Sort by hours (0-23)
    count_sort_by_part(2, 31, get_day);      // Sort by day (1-31)
    count_sort_by_part(1, 12, get_month);    // Sort by month (1-12)
    count_sort_by_part(0, 9999, get_year);   // Sort by year (0-9999)
}
// Distributed Count Sort for small datasets
void countSort(File *arr, int n, int (*compare)(const void *, const void *)) {
    File *output = malloc(n * sizeof(File));
    int count[MAX_FILES] = {0};

    for (int i = 0; i < n; i++) {
        count[arr[i].id]++;
    }

    for (int i = 1; i < MAX_FILES; i++) {
        count[i] += count[i - 1];
    }

    for (int i = n - 1; i >= 0; i--) {
        output[count[arr[i].id] - 1] = arr[i];
        count[arr[i].id]--;
    }

    for (int i = 0; i < n; i++) {
        arr[i] = output[i];
    }

    free(output);
}

// Merge function for merge sort
void merge(File *arr, int left, int mid, int right, int (*compare)(const void *, const void *)) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    File *L = malloc(n1 * sizeof(File));
    File *R = malloc(n2 * sizeof(File));

    for (int i = 0; i < n1; i++) {
        L[i] = arr[left + i];
    }
    for (int i = 0; i < n2; i++) {
        R[i] = arr[mid + 1 + i];
    }

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (compare(&L[i], &R[j]) <= 0) {
            arr[k++] = L[i++];
        } else {
            arr[k++] = R[j++];
        }
    }

    while (i < n1) {
        arr[k++] = L[i++];
    }
    while (j < n2) {
        arr[k++] = R[j++];
    }

    free(L);
    free(R);
}

// Merge Sort
void mergeSort(File *arr, int left, int right, int (*compare)(const void *, const void *)) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid, compare);
        mergeSort(arr, mid + 1, right, compare);
        merge(arr, left, mid, right, compare);
    }
}

// Coordinator function to decide and execute sorting strategy
void coordinator() {
    int (*compare)(const void *, const void *);
    if (strcmp(sortBy, "ID") == 0) {
        compare = compareByID;
    } else if (strcmp(sortBy, "Name") == 0) {
        compare = compareByName;
    } else if (strcmp(sortBy, "Timestamp") == 0) {
        compare = compareByTimestamp;
    } else {
        fprintf(stderr, "Invalid sorting parameter\n");
        return;
    }

    if (file_count <= THRESHOLD) {
        // Use Distributed Count Sort
        printf("Sorting by: %s (Using Count Sort)\n", sortBy);
        if(strncmp(sortBy, "Name", 4) == 0) {
            radixSortFilesByName(files, file_count, MAX_NAME_LENGTH);
        
        }
        else if(strncmp(sortBy, "Timestamp", 9) == 0) {
            count_sort_timestamps();
        }
        else {
        countSort(files, file_count, compare);
        }
    } else {
        // Use Distributed Merge Sort
        printf("Sorting by: %s (Using Merge Sort)\n", sortBy);
        mergeSort(files, 0, file_count - 1, compare);
    }
}

// Main function
int main() {
    // Read file count and file data
    scanf("%d", &file_count);
    num_files = file_count;
    for (int i = 0; i < file_count; i++) {
        scanf("%s %d %s", files[i].name, &files[i].id, files[i].timestamp);
    }

    // Read sorting parameter
    scanf("%s", sortBy);

    coordinator();

    // Print sorted data
    for (int i = 0; i < file_count; i++) {
        printf("%s %d %s\n", files[i].name, files[i].id, files[i].timestamp);
    }

    return 0;
}
